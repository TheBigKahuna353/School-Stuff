#if !defined(H_WORLD)
#define H_WORLD

#include "SceneObject.h"
#include <vector>


void createObjects();

#endif
