#ifndef MANDELBROT_H
#define MANDELBROT_H

#include <glm/glm.hpp>

glm::vec3 getColorInSet(float x, float y);

#endif